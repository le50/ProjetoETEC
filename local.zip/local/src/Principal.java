
public class Principal {

	public static void main(String[] args) {
		
		// Criar um objeto = Instanciar a classe
		Endereco endereco_1 = new Endereco("RuaUm", "Assis", "SP"); // Par�metros do Const
		Endereco endereco_2 = new Endereco(); // Par�metros do Const
		
		System.out.println(endereco_1.getRua()); // Pegar informa��o
		System.out.println(endereco_1.getCidade()); // sysout + ctrl + Space
		System.out.println(endereco_1.getEstado()); 
		
		endereco_2.setRua("Rua Luiz");
		endereco_2.setcidade("Londrina");
		
		System.out.println(endereco_2.getRua()); // Pegar informa��o
		System.out.println(endereco_2.getCidade()); 
	}

}
